import React from "react";

function ChartSection() {
  return (
    <div style={{ padding: "1rem" }}>
      <h2>📈 차트 화면</h2>
      <p>여기에 Candle, Line 차트, RSI, MACD 등의 그래프가 들어갈 예정!</p>
      {/* 차트 라이브러리를 사용해 실제 차트 구현 */}
    </div>
  );
}

export default ChartSection;
