// FortuneSection.js

import React, { useEffect, useState } from "react";

function FortuneSection() {
  const fortunes = [
    "오늘은 새로운 기회가 생길 수도!",
    "즐거운 일이 생길 듯한 하루!",
    "큰 지출이 예상되니 조심합시다!",
    "귀인이 나타날 수 있어요. 주변에 주목!"
  ];
  const [fortune, setFortune] = useState("");

  useEffect(() => {
    const randomIndex = Math.floor(Math.random() * fortunes.length);
    setFortune(fortunes[randomIndex]);
  }, [fortunes]); // 여기서 [fortunes]로 수정!

  return (
    <div style={{ padding: "1rem" }}>
      <h2>🔮 오늘의 운세</h2>
      <p>{fortune}</p>
    </div>
  );
}

export default FortuneSection;
