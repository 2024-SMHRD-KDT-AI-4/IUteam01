// Dashboard.js
import React, { useState } from "react";
import ChartSection from "./ChartSection";
import NewsSection from "./NewsSection";
import FortuneSection from "./FortuneSection";


function Dashboard() {
  const [activeTab, setActiveTab] = useState("chart");
  const [darkMode, setDarkMode] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const handleTabChange = (tabName) => {
    setActiveTab(tabName);
  };

  const toggleDarkMode = () => {
    setDarkMode((prev) => !prev);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    alert(`검색어: ${searchTerm}`);
  };

  // 로그인 새창 열기
  const handleLogin = () => {
    window.open("/login.html", "loginWindow", "width=400,height=500");
  };

  // 회원가입 새창 열기
  const handleSignUp = () => {
    window.open("/signup.html", "signupWindow", "width=400,height=500");
  };

  return (
    <div className={`dashboard ${darkMode ? "dark-mode" : ""}`}>
      {/* 상단 네비게이션 영역 */}
      <header className="top-nav">
        {/* 왼쪽 탭 버튼들 */}
        <div className="nav-left">
          <button
            className={activeTab === "chart" ? "active" : ""}
            onClick={() => handleTabChange("chart")}
          >
            📈 차트
          </button>
          <button
            className={activeTab === "news" ? "active" : ""}
            onClick={() => handleTabChange("news")}
          >
            📰 뉴스
          </button>
          <button
            className={activeTab === "fortune" ? "active" : ""}
            onClick={() => handleTabChange("fortune")}
          >
            🔮 운세
          </button>
        </div>

        {/* 검색 폼 */}
        <form className="search-form" onSubmit={handleSearchSubmit}>
          <input
            type="text"
            placeholder="검색어"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button type="submit">검색</button>
        </form>

        {/* 우측 버튼들: 다크모드, 로그인, 회원가입 */}
        <div className="nav-right">
          <button onClick={toggleDarkMode}>
            {darkMode ? "🌕 라이트모드" : "🌑 다크모드"}
          </button>
          <button onClick={handleLogin}>로그인</button>
          <button onClick={handleSignUp}>회원가입</button>
        </div>
      </header>

      {/* 메인 콘텐츠: 탭에 따라 다른 컴포넌트 표시 */}
      <main className="main-content">
        {activeTab === "chart" && <ChartSection />}
        {activeTab === "news" && <NewsSection />}
        {activeTab === "fortune" && <FortuneSection />}
        {/*                 여기 ^^^^^^^^^^^^^^^ 꼭 ' />' 로 끝나야 합니다 */}
      </main>
    </div>
  );
}

export default Dashboard;
