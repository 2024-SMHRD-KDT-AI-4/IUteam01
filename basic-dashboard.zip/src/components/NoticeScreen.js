import React from "react";


function NoticeScreen({ handleContinue }) {
  return (
    <div className="notice-screen">
      <h1>📢 이용 안내 (필수 확인)</h1>
      <p>
        📌본 서비스는 투자 참고용으로, 투자 조언이나 보장을 제공하지 않습니다.
        <br />
        {/* ...기타 주의사항 내용 */}
        <br />
        <span>📌 위 내용을 확인하였으며, 본인의 판단하에 서비스를 이용하겠습니다.</span>
      </p>
      <button onClick={handleContinue} className="continue-button">
        [동의하고 계속하기]
      </button>
    </div>
  );
}

export default NoticeScreen;
