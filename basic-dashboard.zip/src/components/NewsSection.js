import React from "react";

function NewsSection() {
  return (
    <div style={{ padding: "1rem" }}>
      <h2>📰 뉴스 화면</h2>
      <p>코인 관련 최신 뉴스를 표시합니다.</p>
      {/* 예: News API를 호출해 뉴스 목록 렌더링 */}
    </div>
  );
}

export default NewsSection;
