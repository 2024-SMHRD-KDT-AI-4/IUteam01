import React, { useState, useEffect } from "react";
import NoticeScreen from "./components/NoticeScreen";
import Dashboard from "./components/Dashboard";
import "./App.css";

function App() {
  // true이면 NoticeScreen 렌더링
  const [showNotice, setShowNotice] = useState(true);

  // '동의하고 계속하기' 버튼 클릭 시 대시보드로 전환
  const handleContinue = () => {
    setShowNotice(false);
  };

  // 50초 후에 자동으로 대시보드로 전환
  useEffect(() => {
    const timer = setTimeout(() => setShowNotice(false), 50000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="App">
      {showNotice ? (
        <NoticeScreen handleContinue={handleContinue} />
      ) : (
        <Dashboard />
      )}
    </div>
  );
}

export default App;
